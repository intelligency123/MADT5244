package com.example.macstudent.drawing;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView imgdog = (ImageView)findViewById(R.id.imagedog);
        Bitmap b = Bitmap.createBitmap(300,500,Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(b);
        Paint paintbrush = new Paint();
        Paint paint = new Paint();
        canvas.drawColor(Color.GRAY);
        paintbrush.setColor(Color.argb(255,255,255,255));
        paint.setColor(Color.argb(255,244,160,0));
       // canvas.drawLine(10,50,200,50,paintbrush);
        RectF rf = new RectF(76,180,200,300);
        canvas.drawCircle(140,140,40,paintbrush);
        canvas.drawCircle(122,122,4,paint);
        canvas.drawCircle(140,140,3,paint);
        canvas.drawCircle(160,122,4,paint);
        canvas.drawLine(130,160,150,160,paint);
        //canvas.drawRect(76,180,200,300,paintbrush);
        canvas.drawRoundRect(rf,150,300,paintbrush);
        canvas.drawLine(83,200,20,100,paintbrush);
        canvas.drawLine(190,200,400,100,paintbrush);
        canvas.drawLine(98,300,90,400,paintbrush);
        canvas.drawLine(175,300,180,400,paintbrush);

        imgdog.setImageBitmap(b);

    }
}
